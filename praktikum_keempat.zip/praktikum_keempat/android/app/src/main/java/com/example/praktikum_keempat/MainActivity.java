package com.example.praktikum_keempat;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
